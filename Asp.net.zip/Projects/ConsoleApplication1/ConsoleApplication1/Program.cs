﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			int[] a = { 23, 5, 3, 44, 77, 3, 90, 100 };
			//int i = 0;
                 foreach ( int i in a)
			{
				if (a[i] > 10)
				{
					System.Console.WriteLine(i);
				}

			}

		}
	}
}
