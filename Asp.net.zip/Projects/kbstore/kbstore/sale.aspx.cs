﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kbstore
{
	public partial class sale : System.Web.UI.Page

	{
		SqlConnection con = null;
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				loadGridData();
			}
		}
		protected void dbconnection()
		{
			String strcon = "Data Source=DESKTOP-J1NS0B9;Initial Catalog=kbstore;Integrated Security=True";
			SqlConnection con = new SqlConnection(strcon);
			con.Open();
		}
		protected void loadGridData()
		{
			dbconnection();
			String query = "SELECT * FROM sale ORDER BY product id";
			
			SqlDataAdapter _da = new SqlDataAdapter(query, con);
			DataTable dt = new DataTable();
			_da.Fill(dt);
			if (dt.Rows.Count > 0)
			{
				GridView1.DataSource = dt;
				GridView1.DataBind();
			}
			con.Close();
		}
		protected void btnsave_Click(object sender, EventArgs e)
		{
			dbconnection();
			SqlCommand cmd = new SqlCommand("insert into sale(productid,productname,saledate,customername,customeraddress,productprice,totalamount)VALUES(@productid,@productname,@saledate,@customername,@customerprice,@productprice,@totalamount)", con);
			cmd.Parameters.AddWithValue("@productid", tbxpid.Text);
			cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
			cmd.Parameters.AddWithValue("@saledate", tbxsdate.Text);
			cmd.Parameters.AddWithValue("@customername", tbxcname.Text);
			cmd.Parameters.AddWithValue("@customeraddress", tbxcaddress.Text);
			cmd.Parameters.AddWithValue("@productprice", tbxpprice.Text);
			cmd.Parameters.AddWithValue("@totalamount", tbxtamount.Text);
			cmd.ExecuteNonQuery();
			con.Close();
			loadGridData();
		}

		protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		protected void btndelete_Command(object sender, CommandEventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("delete sale where productid=@productid", con);
				cmd.Parameters.AddWithValue("@productid", e.CommandArgument.ToString());
				cmd.ExecuteNonQuery();
				lblmessage.Text = "delete sucessfully";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				con.Close();
				loadGridData();
			}
			catch (Exception ex)
			{
				throw;
			}
		}


		protected void btnedit_Click(object sender, EventArgs e)
		{
			dbconnection();
			btnsave.Enabled = false;
			SqlCommand cmd = new SqlCommand("select * from sale where productid=@productid", con);
			cmd.Parameters.AddWithValue("@productid", e.ToString());
			var datareader = cmd.ExecuteReader();
			DataTable dt = new DataTable();
			dt.Load(datareader);
			if (dt.Rows.Count > 0)
			{
				tbxpid.Text = dt.Rows[0]["productid"].ToString();
				tbxpname.Text = dt.Rows[0]["productname"].ToString();
				tbxsdate.Text = dt.Rows[0]["saledate"].ToString();
				tbxcname.Text = dt.Rows[0]["customername"].ToString();
				tbxcaddress.Text = dt.Rows[0]["cusomeraddress"].ToString();
				tbxpprice.Text = dt.Rows[0]["productprice"].ToString();
				tbxtamount.Text = dt.Rows[0]["totalamount"].ToString();
			}
			else
			{

			}
			con.Close();
		}

		protected void btnupdate_Click(object sender, EventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("update sale set productid=@productid,productname=@productname,saledate=@saledate,customername=@customername,customeraddress=@customeraddress,productprice=@productprice,totalamount=@totalamount", con);
				cmd.Parameters.AddWithValue("productid", tbxpid.Text);
				cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
				cmd.Parameters.AddWithValue("@saledate", tbxsdate.Text);
				cmd.Parameters.AddWithValue("@customername", tbxcname.Text);
				cmd.Parameters.AddWithValue("@customeraddress", tbxcaddress.Text);
				cmd.Parameters.AddWithValue("@productprice", tbxpprice.Text);
				cmd.Parameters.AddWithValue("@totalamount", tbxtamount.Text);
				cmd.ExecuteNonQuery();
				lblmessage.Text = "update sucessful";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				clearText();
				con.Close();
				loadGridData();
				btnsave.Enabled = true;
			}
			catch (Exception)
			{
				throw;
			}
		}







		protected void clearText()
		{
			tbxpid.Text = tbxpname.Text = tbxsdate.Text = tbxcname.Text = tbxcaddress.Text = tbxpprice.Text = tbxtamount.Text = "";
		}
	}
}
	
	
