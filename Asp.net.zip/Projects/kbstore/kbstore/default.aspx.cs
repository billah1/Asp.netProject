﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kbstore
{
	public partial class _default : System.Web.UI.Page
	{
		SqlConnection con = null;
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void dbConnection()
		{
			String strcon = "Data Source=DESKTOP-J1NS0B9;Initial Catalog=kbstore;Integrated Security=True";
			con = new SqlConnection(strcon);

			con.Open();
		}
		protected void login()
		{
			dbConnection();
			string query = "select * from userr where username='" + tbxusername.Text + "' and password='" + tbxpassword.Text + "'";
			SqlDataAdapter ad = new SqlDataAdapter(query, con);
			DataTable dt = new DataTable();
			ad.Fill(dt);

			if (dt.Rows.Count > 0)
			{
				Session["username"] = dt.Rows[0]["username"].ToString();
				con.Close();
				Response.Redirect("~/product.aspx");
			}
			else
			{
				Response.Redirect("Invalid username or password");
			}


		}
		protected void btnlogin_Click(object sender, EventArgs e)
		{
			login();
		}
	}
}




		
	