﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kbstore
{
	public partial class bill : System.Web.UI.Page
	{
		SqlConnection con = null;
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				loadGridData();
			}
		}
		protected void dbconnection()
		{
			try
			{
				String strcon = "Data Source=DESKTOP-J1NS0B9;Initial Catalog=kbstore;Instegrated Security=True";
				con = new SqlConnection(strcon);
				con.Open();
			}
			catch (Exception)
			{
				throw;
			}
		}
		protected void loadGridData()
		{
			String query = "SELECT * FROM bill";
			DataTable dt = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter(query, con);
			da.Fill(dt);
			if(dt.Rows.Count > 0)
			{
				GridView2.DataSource = dt;
				GridView2.DataBind();
			}
			con.Close();

		}
		protected void btnsave_Click(object sender, EventArgs e)
		{
			dbconnection();
			SqlCommand cmd = new SqlCommand("insert into bill(productid,productname,saledate,customername,customeraddress,productprice,totalamount)VALUES(@product id,@product name,@sale date,@customer name,@customer addresss,@product price,@total amount)", con);
			cmd.Parameters.AddWithValue("@productid", tbxpid.Text);
			cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
			cmd.Parameters.AddWithValue("@saledate", tbxsdate.Text);
			cmd.Parameters.AddWithValue("@customername", tbxcname.Text);
			cmd.Parameters.AddWithValue("@customeraddress", tbxcaddress.Text);
			cmd.Parameters.AddWithValue("productprice", tbxpprice.Text);
			cmd.Parameters.AddWithValue("totalamount", tbxtamount.Text);
			cmd.ExecuteNonQuery();
			con.Close();
			clearText();
			loadGridData();
		}

		protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		protected void btndelete_Command(object sender, CommandEventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("delete bill where productid=@productid", con);
				cmd.Parameters.AddWithValue("@productid", e.CommandArgument.ToString());
				cmd.ExecuteNonQuery();
				lblmessage.Text = "delete sucessfully";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				con.Close();
				loadGridData();
			}
			catch (Exception ex)
			{
				throw;
			}
		}

		protected void btnedit_Click(object sender, EventArgs e)
		{

			dbconnection();
			btnsave.Enabled = false;
			SqlCommand cmd = new SqlCommand("select * from product where productid=@productid", con);
			cmd.Parameters.AddWithValue("@productid", e.ToString());
			var datareader = cmd.ExecuteReader();
			DataTable dt = new DataTable();
			dt.Load(datareader);
			if (dt.Rows.Count > 0)
			{
				tbxpid.Text = dt.Rows[0]["productid"].ToString();
				tbxpname.Text = dt.Rows[0]["productname"].ToString();
				tbxsdate.Text = dt.Rows[0]["saledate"].ToString();
				tbxcname.Text = dt.Rows[0]["customername"].ToString();
				tbxcaddress.Text = dt.Rows[0]["cusomeraddress"].ToString();
				tbxpprice.Text = dt.Rows[0]["productprice"].ToString();
				tbxtamount.Text = dt.Rows[0]["totalamount"].ToString();
			}
			else
			{

			}
			con.Close();
		}

		protected void btnupdate_Click(object sender, EventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("update bill set productid=@productid,productname=@productname,saledate=@saledate,customername=@customername,customeraddress=@customeraddress,productprice=@productprice,totalamount=@totalamount", con);
				cmd.Parameters.AddWithValue("productid", tbxpid.Text);
				cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
				cmd.Parameters.AddWithValue("@saledate", tbxsdate.Text);
				cmd.Parameters.AddWithValue("@cusomername", tbxcname.Text);
				cmd.Parameters.AddWithValue("@customeraddress", tbxcaddress.Text);
				cmd.Parameters.AddWithValue("@productprice", tbxpprice.Text);
				cmd.Parameters.AddWithValue("@totalamount", tbxtamount.Text);
				cmd.ExecuteNonQuery();
				lblmessage.Text = "update sucessful";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				clearText();
				con.Close();
				loadGridData();
				btnsave.Enabled = true;
			}
			catch (Exception)
			{
				throw;
			}
		}
		protected void clearText()
		{
			tbxpid.Text = tbxpname.Text = tbxsdate.Text = tbxcname.Text = tbxcaddress.Text = tbxpprice.Text =tbxtamount.Text= "";
		}
	}
}
	
