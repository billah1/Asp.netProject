﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kbstore
{
	public partial class product : System.Web.UI.Page
	{
		SqlConnection con = null;
		protected void Page_Load(object sender, EventArgs e)
		{
			if (Session["username"] == null)
				Response.Redirect("~/default.aspx", true);
			lblmessage.Text = "login successful";
			lblmessage.ForeColor = System.Drawing.Color.Green;

			if (Session["username"] == null)
				Response.Redirect("~/default.aspx");
			if (!IsPostBack)
			{
				loadGridData();
			}
		}
		protected void dbconnection()
		{
			try
			{
				String Strcon = "Data Source=DESKTOP-J1NS0B9;Initial Catalog=kbstore;Integrated Security=True";
				con = new SqlConnection(Strcon);
				con.Open();
			}
			catch (Exception)
			{
				throw;
			}
		}
		protected void loadGridData()
		{
			dbconnection();
			String query = "SELECT * FROM product ";
			DataTable dt = new DataTable();
			SqlDataAdapter _da = new SqlDataAdapter(query, con);
			_da.Fill(dt);
			//product.DataSource = dt;
			//product.DataBind();
			con.Close();


			if(dt.Rows.Count > 0)
			{
				GridView.DataSource = dt;
				GridView.DataBind();
			}
			con.Close();
		}

		protected void btnsave_Click(object sender, EventArgs e)
		{
			dbconnection();
			SqlCommand cmd = new SqlCommand("insert into product(productid,productname,productgroup,productprice) VALUES (@productid,@productname,@productgroup,@productprice)", con);
			cmd.Parameters.AddWithValue("@productid", tbxpid.Text);
			cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
			cmd.Parameters.AddWithValue("@productgroup", tbxpgroup.Text);
			cmd.Parameters.AddWithValue("@productprice", tbxpprice.Text);
			cmd.ExecuteNonQuery();
			lblmessage.Text = "save successsful";
			lblmessage.ForeColor = System.Drawing.Color.Green;
			con.Close();
			clearText();
			loadGridData();

		}

		protected void GridView_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		protected void btndelete_Command(object sender, CommandEventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("delete product where productid=@productid", con);
				cmd.Parameters.AddWithValue("@productid", e.CommandArgument.ToString());
				cmd.ExecuteNonQuery();
				lblmessage.Text = "delete sucessful";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				con.Close();
				loadGridData();
			}
			catch(Exception ex)
			{
               
			}
			
			
		}

		protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
		{

		}

		/*protected void btnedit_Click(object sender, EventArgs e)
		{
			dbconnection();

			btnsave.Enabled = false;
			SqlCommand cmd = new SqlCommand("select * from product where product id=@product id", con);
			cmd.Parameters.AddWithValue("@Product id", e.commandArgument.ToString());
			var dataReader = cmd.ExecuteReader();
			DataTable dt = new DataTable();
			dt.Load(dataReader);
			if(dt.Rows.Count > 0)
			{
				tbxpid.Text = dt.Rows[0]["product id"].ToString();
				tbxpname.Text = dt.Rows[0]["product name"].ToString();
				tbxpgroup.Text = dt.Rows[0]["product group"].ToString();
				tbxpprice.Text = dt.Rows[0]["product price"].ToString();
			}
			else
			{

			}
			con.Close();
		}*/

		protected void btnupdate_Click(object sender, EventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("update product set productid=@productid,productname=@productname,productgroup=@productgroup,productprice=@productprice", con);
				cmd.Parameters.AddWithValue("productid", tbxpid.Text);
				cmd.Parameters.AddWithValue("@productname", tbxpname.Text);
				cmd.Parameters.AddWithValue("productgroup", tbxpgroup.Text);
				cmd.Parameters.AddWithValue("productprice", tbxpprice.Text);
				cmd.ExecuteNonQuery();
				lblmessage.Text = "update sucessful";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				clearText();
				con.Close();
				loadGridData();
				btnsave.Enabled = true;
			}
			catch (Exception)
			{
				throw;
			}
		}
		

		protected void btnedit_Command(object sender, CommandEventArgs e)
		{
			dbconnection();

			btnsave.Enabled = false;
			SqlCommand cmd = new SqlCommand("select * from product where productid=@productid", con);
			cmd.Parameters.AddWithValue("@Productid", e.ToString());
			var dataReader = cmd.ExecuteReader();
			DataTable dt = new DataTable();
			dt.Load(dataReader);
			if (dt.Rows.Count > 0)
			{
				tbxpid.Text = dt.Rows[0]["productid"].ToString();
				tbxpname.Text = dt.Rows[0]["productname"].ToString();
				tbxpgroup.Text = dt.Rows[0]["productgroup"].ToString();
				tbxpprice.Text = dt.Rows[0]["productprice"].ToString();
			}
			else
			{

			}
			con.Close();
		}
		protected void clearText()
		{
			tbxpid.Text = tbxpname.Text = tbxpgroup.Text = tbxpprice.Text = "";
		}

		protected void btndelete_Command1(object sender, CommandEventArgs e)
		{

		}

		protected void btnedit_Click(object sender, EventArgs e)
		{

		}

		protected void btnsave_Click1(object sender, EventArgs e)
		{

		}
	}
}