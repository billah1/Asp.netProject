﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kbstore
{
	public partial class employee : System.Web.UI.Page
	{
		SqlConnection con = null;
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				loadGridData();
			}
		}
		protected void dbconnection()
		{
			try
			{
				String strcon = "Data Source=DESKTOP-J1NS0B9;Initial Catalog=kbstore;Integrated Security=True";
				con = new SqlConnection(strcon);
				con.Open();
			}
			catch (Exception)
			{
				throw;
			}
		}
		protected void loadGridData()
		{
			dbconnection();

			String query = "SELECT * FROM employee ";
			DataTable dt = new DataTable();
			SqlDataAdapter da = new SqlDataAdapter(query, con);
			da.Fill(dt);
			
			
			if (dt.Rows.Count > 0)
			{
				GridView3.DataSource = dt;
				GridView3.DataBind();
			}
			con.Close();
		}
		
		protected void btnsave_Click(object sender, EventArgs e)
		{
			dbconnection();
			SqlCommand cmd = new SqlCommand("insert into employee(employeeid,employeename,employeeaddress,employeeage,emplyeegender,employeesalary)VALUES(@employeeid,@employeename,@employeeaddress,@employeeage,@employeegender,@employeesalary)", con);
			cmd.Parameters.AddWithValue("@employeeid", tbxeid.Text);
			cmd.Parameters.AddWithValue("@employeename", tbxename.Text);
			cmd.Parameters.AddWithValue("@employeeaddress", tbxeaddress.Text);
			cmd.Parameters.AddWithValue("@employeeage", tbxeage.Text);
			cmd.Parameters.AddWithValue("@employeegender", tbxegender.Text);
			cmd.Parameters.AddWithValue("@employeesalary", tbxesalary.Text);
			//cmd.ExecuteNonQuery();
			con.Close();
			loadGridData();
		}

		protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		protected void btndelete_Command(object sender, CommandEventArgs e)
		{
			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("delete employee where employeeid=@employeeid", con);
				cmd.Parameters.AddWithValue("@employeeid", e.CommandArgument.ToString());
				cmd.ExecuteNonQuery();
				lblmessage.Text = "delete sucessfully";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				con.Close();
				loadGridData();
			}
			catch(Exception ex)
			{
				throw;
			}
		}

		protected void btnedit_Click(object sender, EventArgs e)
		{

			dbconnection();
			btnsave.Enabled = false;
			SqlCommand cmd = new SqlCommand("select * from employee where employeeid=@employeeid", con);
			cmd.Parameters.AddWithValue("@employeeid", e.ToString());
			var datareader = cmd.ExecuteReader();
			DataTable dt = new DataTable();
			dt.Load(datareader);
			if(dt.Rows.Count > 0)
			{
				tbxeid.Text = dt.Rows[0]["employeeid"].ToString();
				tbxename.Text = dt.Rows[0]["employeename"].ToString();
				tbxeaddress.Text = dt.Rows[0]["employeeaddress"].ToString();
				tbxeage.Text = dt.Rows[0]["employeeage"].ToString();
				tbxegender.Text = dt.Rows[0]["employeegender"].ToString();
				tbxesalary.Text = dt.Rows[0]["employeesalary"].ToString();
			}
			else
			{

			}
			con.Close();
			

		}

		protected void btnupdate_Click(object sender, EventArgs e)
		{

			try
			{
				dbconnection();

				SqlCommand cmd = new SqlCommand("update employee set employeeid=@employeeid,employeename=@employeename,employeeaddresss=@employeeaddress,employeeage=@employeeage,employeegender=@employeegender,employeesalary=@employeesalary", con);
				cmd.Parameters.AddWithValue("employeeid", tbxeid.Text);
				cmd.Parameters.AddWithValue("@employeename", tbxename.Text);
				cmd.Parameters.AddWithValue("@employeeaddress", tbxeaddress.Text);
				cmd.Parameters.AddWithValue("@employeeage", tbxeage.Text);
				cmd.Parameters.AddWithValue("@employeegender", tbxegender.Text);
				cmd.Parameters.AddWithValue("@employeesalary", tbxesalary.Text);
				cmd.ExecuteNonQuery();
				lblmessage.Text = "update sucessful";
				lblmessage.ForeColor = System.Drawing.Color.Green;
				clearText();
				con.Close();
				loadGridData();
				btnsave.Enabled = true;
			}
			catch (Exception)
			{
				throw;
			}
		}
		protected void clearText()
		{
			tbxeid.Text = tbxename.Text = tbxeaddress.Text = tbxeage.Text = tbxegender.Text = tbxesalary.Text = "";
		}
	}
	}
